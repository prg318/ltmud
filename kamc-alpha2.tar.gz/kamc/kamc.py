#!/usr/bin/python2.5
# Lukas Sabota <punkrockguy318@comcast.net>
# Licensed under GPL
#
# Version 0.3.1 
"""
Purpose:

KAMC is designed to be a completely modular MUD client, with scriptability in
mind.  Want a feature?  Write a plugin.  Don't like a feature?  Turn a plugin
off. 

The base of KAMC is simple:  only a basic output window, an input entry, and
a connection manager.  All extra functionality will be written through plugins.

Since plugins have direct access to the telnet client and the gui, the
sky is the limit for plugins.  All plugins are just simple plugin scripts. Take
a look at plugins/example.py.

KAMC has only been tested on Ubuntu Linux, but should be portable to any
other platform due to python's nature.

KAMC is licensed under the GPL, so anyone can contribute to it and redistribute
it.
"""
"""
ToDo:
* ANNOYANCE: scrolling with keyboard goes below terminal
* Remember options from connection window
* Load ASCII colors from config file
* Make compatible with py2.6

"""
"""
Log:
3/28/09 - yup its been a long time since I updated this.  I changed the default window size and I also changed the defualt MUD.
DragonsExodus is dead.  Dark and Shattered Lands, however, lives on.  I'm in the works of rewriting this BTW.
2/1/08 - today i worked in the scrollbars, however they will scroll below the bottom of the buffer, which is annoying.  Scrolling with the mouse does not do this.  This needs to be fixed.  But at least scrolling works somehwat with keyboard.  I hate using the fucking mouse
-- version 0.3 --
1/29/08 - I cleaned up the colors code today.  No more ugly gdk color functions; everything is now just standard hex codes.  It's also commented.  That was a bitch.  Idk why I didn't comment them the first time, but it was a PITA trying to figure out which color was which.  Need nicotine.
1/28/08 - Okay, still having problems with the pickle function.  Oh well, it's  a problem for another night.  Goodnight.
1/28/08 - I started to write the pickle routines for remembering setting, but it currently won't load the settings.  This needs to be fixed.
1/28/08 - It's been an awful while!  I've looked through the code and started cleaning some things.  I'm probably going to make kamc remember your connection settings on exit after checking back to see how i've done it in earlier projects.  (I've started playing Dragons Exodus again lol)
-- version 0.2 --
11/8/06 - Usable client created.  Plugin system implemented.  
11/7/06 - Rewrite begun.  Basic UI has been reconstructed.
Inter-window communication must be planned out.
"""
import gtk
import gobject
import vte
import pickle

class Client:
  def __init__(self):
    import telnetlib
    self.connected = False
    self.tn = telnetlib.Telnet()
    self.in_filters = []
    
  def disconnect(self):
    print "disconnecting"
    self.tn.close()
    self.connected = False
    
  def connect(self, host, port):
    print "connecting to ", host, port
    self.tn.open(host, port)

    print "connected..."
    self.connected = True
 
  def run_script(self, file_name):
    script = open(file_name, 'r')
    try:
      for line in script:
        self.write(line)
    finally:
      script.close()

  def read(self):
    """ read()
    This function returns a tuple: (data, status)
    If there is no data, it will return None.
    If we've been disconnected, status = -1
    """
    data = ''
    while 1:
      try:
        x = self.tn.read_eager()
      except EOFError:
        self.disconnect()
        return (data, -1)
      if x == '':
        break
      data = data + x
    
    if data == '':
      return None, 0
    return (data, 0)

  def write(self, msg):
    if self.connected:
      for x in self.in_filters:
        msg = x(msg)
      #msg = my_script(msg)
      msg = msg + '\n'
      self.tn.write(msg)
 
  

   
class MainWindow:
  # move me
  def quit(self, arg1, arg2="foo"):
    settings.save()
    gtk.main_quit()

# this code is no longer neccessary because of the scrollbar widget

#  def key_press(self, widget, event):
    #print "%d pressed." % event.keyval
#    pg_up = 65365
#    pg_down = 65366
    
    #TODO: how the fuck can i scroll the vterm?
#    if event.keyval == pg_up:
#      new_value = self.vterm.get_adjustment().get_value() - 10
#      self.vterm.get_adjustment().set_value(new_value)
      # scroll up
      
#      pass
#    if event.keyval == pg_down:
#      self.scroll_bar.set_fill_level(0)
#      new_value = self.vterm.get_adjustment().get_value() + 10
      #print new_value
      #if new_value < 0:
      #  new_value = 0
#      self.vterm.get_adjustment().set_value(new_value)

      # scroll down
#      pass
 

  def __init__(self, tn):
    self.client = tn
    
    win = gtk.Window()

    #win.add_events(gtk.gdk.KEY_PRESS_MASK)
    #win.connect("key-press-event", self.key_press)
    win.set_title("Kick Ass MUD Client")
    win.set_default_size(700, 900)
    win.connect("delete_event", self.quit)
    
    vbox = gtk.VBox()
    hbox = gtk.HBox()
    
    menu  = self.__create_menu()
    vterm = self.__create_vterm()
    scroll_bar = gtk.VScrollbar(vterm.get_adjustment())
    scroll_bar.set_restrict_to_fill_level(True)
    entry = gtk.Entry()
    entry.connect("activate", self.__enter_pressed)
    
    vbox.pack_start(menu, expand=False)
    hbox.pack_start(vterm)
    hbox.pack_start(scroll_bar, expand=False)
    vbox.pack_start(hbox)
    vbox.pack_start(entry, expand=False)
    win.add(vbox)

    self.win    = win
    self.menu   = menu
    self.entry  = entry
    self.vterm  = vterm
    self.scroll_bar = scroll_bar
    self.vterm.connect("focus-in-event",(lambda widget, arg: entry.grab_focus()))
    
    self.load_plugins()
  
  def __create_menu(self):
    ui_info = \
    """
    <ui>
      <menubar name ='MenuBar'>
        <menu action='FileMenu'>
          <menuitem action='Connect'/>
          <menuitem action='Disconnect'/>
          <separator/>
          <menuitem action='Quit'/>
        </menu>
      </menubar>
    </ui>
    """
    entries = (
    ( "FileMenu", None, "_File"),
    ( "Connect", gtk.STOCK_CONNECT, "C_onnect", None, None, self.__connect_clicked),
    ( "Disconnect", gtk.STOCK_DISCONNECT, "_Disconnect", None, None, self.__disconnect_clicked),
    ( "Quit", gtk.STOCK_QUIT, "_Quit", None, None, self.quit)
    )

    action = gtk.ActionGroup("Actions")
    action.add_actions(entries)
    
    
    
    ui = gtk.UIManager()
    ui.insert_action_group(action,0)
    
    try:
      mergeid = ui.add_ui_from_string(ui_info)
    except gobject.GError, msg:
      print "building menus failed: %s" % msg
      return None
    self.ui = ui 
    return ui.get_widget("/MenuBar")
  
  def __create_vterm(self):
    vterm = vte.Terminal()
    fg = gtk.gdk.Color(65535, 65535, 65535)
    bg = gtk.gdk.Color(0, 0, 0)
    hex_list = [
    "#000000", # black
    "#C80000", # darkred
    "#00C800", # darkblue
    "#C87D00", # orange
    "#007DC8", # darkcyan
    "#C800C8", # darkpurple
    "#00C8C8", # darkgreen 
    "#C8C8C8", # lightgrey
    "#828282", # darkgrey
    "#FF0564", # brightred
    "#64FF64", # brightgreen
    "#FFFF64", # yellow
    "#6464FF", # lightblue
    "#FF00FF", # lightpurple
    "#64FFFF", # lightcyan
    "#FFFFFF" # white
    ]

    colors = []                
    for x in hex_list:
      colors.append(gtk.gdk.color_parse(x))
    

    vterm.set_colors(fg, bg, colors)
    vterm.set_opacity(65535)
    vterm.set_scrollback_lines(1000)
    
    return vterm
    
  def load_plugins(self):
    # This plugin list stuff is just temporary.
    plugin_list = ['numpad', 'command-list', 'search'] 
    for x in plugin_list:
      y = __import__("plugins/%s" % x)
      plugin = y.KAMCPlugin(self.client, self)
  
  def show(self):
    self.win.show_all()  
   
  def __connect_clicked(self, widget):
    cn = ConnectWindow(self)
    cn.show()
  
  def __disconnect_clicked(self, widget):
    self.client.disconnect()
    
  def timeout(self):
    if not self.client.connected:
      return False
    x = self.client.read()
    # Redeclared for clarity
    data = x[0]
    status = x[1]
    if data:
      self.vterm.feed(data)
    # status == 1 when disconnected
    if status == -1:
      self.display_msg("Disconnected by remote host.")
      return False
    return True
  
  def display_msg(self, string):
    string = "*** " + string + " ***"
    self.vterm.feed('\r\n')
    self.vterm.feed(string)
  
  def __enter_pressed(self, widget):
    self.client.write(self.entry.get_text())
    self.entry.set_property("has-focus", True)
    self.vterm.feed('\r\n')

class ConnectWindow:
  def __init__(self, parent):
    self.parent = parent
  
    win = gtk.Window()
    win.set_title("Connect...")
    win.set_default_size(200, 100)
    win.set_position(gtk.WIN_POS_CENTER)
    win.set_resizable(False)
    table = gtk.Table(rows=3, columns=2, homogeneous=False)
    table.set_col_spacings(5)
    table.set_row_spacings(5)
    table.set_border_width(5)
    entry = gtk.Entry()
    entry.set_text(settings.hostname)
    entry2 = gtk.Entry()
    entry2.set_text(settings.port)
    label = gtk.Label("Host:")
    label2 = gtk.Label("Port:")
    ok_but = gtk.Button("Connect", stock=gtk.STOCK_CONNECT)
    ok_but.connect("clicked", self.connect)
    ok_but.set_flags(gtk.CAN_DEFAULT)
    no_but = gtk.Button("Cancel", stock=gtk.STOCK_CANCEL)
    no_but.connect("clicked", self.cancel)
    table.attach(label, 0, 1, 0, 1)
    table.attach(label2, 0,1,1,2)
    table.attach(entry, 1, 2 ,0, 1)
    table.attach(entry2, 1, 2, 1, 2)
    table.attach(no_but, 0, 1, 2, 3)
    table.attach(ok_but, 1, 2, 2, 3)
    win.add(table)
    ok_but.grab_default()
    ok_but.grab_focus()
    self.win          = win
    self.host_entry   = entry
    self.port_entry   = entry2
    
  
  def show(self):
    self.win.show_all()
  
  def connect(self, widget):
    print 'connect!'
    settings.hostname = self.host_entry.get_text()
    settings.port = self.port_entry.get_text()
    self.win.destroy()
    self.parent.client.connect(self.host_entry.get_text(), int(self.port_entry.get_text()))
    gobject.timeout_add(300, self.parent.timeout)
  
  def cancel(self, widget):
    self.win.destroy()


class UserSettings:
  options_file = ".kamc_settings"
  #hostname = "ds.mudmagic.com"
  #port = "1234"
  def __init__(self):
    self.hostname = "dsl-mud.org"
    self.port = "443"
  def load(self):
    try:
      ifile = file(self.options_file, 'r')
      self = pickle.load(ifile)
      ifile.close()
    except IOError:
      print "settings not found. setting defaults..."
  def save(self):
    ofile = file(self.options_file, 'w')
    pickle.dump(self, ofile)
    ofile.close()
    print self.hostname
    print self.port
    print "options file saved to " + self.options_file

if __name__ == "__main__":
  settings = UserSettings()
  settings.load()
  tn = Client()
  main = MainWindow(tn)

  main.show()
  
  gtk.main()
  
  
