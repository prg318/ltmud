#!/usr/bin/python

class KAMCScript:
  def __init__(self, tn, gui):
    print "hello world" 


    


