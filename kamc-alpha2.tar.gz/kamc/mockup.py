#!/usr/bin/env python

# First run tutorial.glade through gtk-builder-convert with this command:
# gtk-builder-convert tutorial.glade tutorial.xml
# Then save this file as tutorial.py and make it executable using this command:
# chmod a+x tutorial.py
# And execute it:
# ./tutorial.py
 
import pygtk
pygtk.require("2.0")
import gtk
import sys
import vte

class MainWindow:
    def __init__(self):
        win = gtk.Window()

        win.set_title("Kick Ass MUD Client II")
        win.set_default_size(700, 400)
        win.connect("delete_event", self.quit)
    
        vbox = gtk.VBox()
        hbox = gtk.HBox()
        
        #TODO
        #menu  = self.__create_menu()
        vterm = self.__create_vterm()
        scroll_bar = gtk.VScrollbar(vterm.get_adjustment())
        scroll_bar.set_restrict_to_fill_level(True)
        entry = gtk.Entry()
        #entry.connect("activate", self.__enter_pressed)
    
        #vbox.pack_start(menu, expand=False)
        hbox.pack_start(vterm)
        hbox.pack_start(scroll_bar, expand=False)
        vbox.pack_start(hbox)
        vbox.pack_start(entry, expand=False)
        win.add(vbox)
        
        win.show_all()
        #self.window = ui.get_object("mainWindow")
        #self.window.show()
        #self.dialog = ui.get_object("connectDialog")
        #self.dialog.show()
    def quit(self, widget=None, data=None):
        sys.exit()
        

class TutorialApp(object):       
    def __init__(self):
        ui = gtk.Builder()
        ui.add_from_file("kamc.glade")
        
        callbacks = GladeCallbacks(ui)
        
        self.ui = ui
        #self.dialog = ui.get_object("prefsDialog")
        #self.dialog.show()
    def __create_vterm(self):
        
        vterm = vte.Terminal()
        fg = gtk.gdk.Color(65535, 65535, 65535)
        bg = gtk.gdk.Color(0, 0, 0)
        hex_list = [
        "#000000", # black
        "#C80000", # darkred
        "#00C800", # darkblue
        "#C87D00", # orange
        "#007DC8", # darkcyan
        "#C800C8", # darkpurple
        "#00C8C8", # darkgreen 
        "#C8C8C8", # lightgrey
        "#828282", # darkgrey
        "#FF0564", # brightred
        "#64FF64", # brightgreen
        "#FFFF64", # yellow
        "#6464FF", # lightblue
        "#FF00FF", # lightpurple
        "#64FFFF", # lightcyan
        "#FFFFFF" # white
        ]

        colors = []                
        for x in hex_list:
            colors.append(gtk.gdk.color_parse(x))
    

        vterm.set_colors(fg, bg, colors)
        vterm.set_opacity(65535)
        vterm.set_scrollback_lines(1000)
    
        return vterm
      
    

class GladeCallbacks:
    def __init__(self, ui):
        ui.connect_signals(self)
        self.ui = ui
        
    def main_connectClicked(self, widget, data=None):
        self.ui.get_object("connectDialog").show()
    
    def main_prefsClicked(self, widget, data=None):
        self.ui.get_object("prefsDialog").show()
    
    def connect_closeClicked(self, widget, data=None):
        self.ui.get_object("connectDialog").hide()
        print 'close'
    
    def prefs_closeClicked(self, widget, data=None):
        self.ui.get_object("prefsDialog").hide()
    
    def showAbout(self, widget=None, data=None):
        self.ui.get_object("aboutDialog").show()
        
    def quit(self, widget, data=None):
        gtk.main_quit()
        sys.exit()


    
    
        
          
  
      
 
if __name__ == "__main__":
  app = TutorialApp()
  gtk.main()
